create database assin2;
use assin2;
create table Publishers(pub_id int primary key,
pub_name varchar(25),
pub_phone varchar(25),
pub_email varchar(25));
create table Authors(a_id int primary key,
a_name varchar(25),
a_phone varchar(25),
a_email varchar(25) unique);
create table subject(s_id int primary key,
s_name varchar(25));
create table Title(titleid int primary key,
titles varchar(25),
pub_id int,
s_id int,
pubdate date,
cover char(1) check (cover in('p','h','p','h')),
price int,
CONSTRAINT TITLE_PUB_ID_FK FOREIGN KEY (PUB_ID) REFERENCES Publishers(PUB_ID),
CONSTRAINT TITLE_S_ID_FK FOREIGN KEY (S_ID) REFERENCES subject(S_ID));
select * from Publishers;
select * from subject;
select * from title;
insert into subject values(1,'ORACLE DATABASE 10g');
insert into subject values(2,'JAVA LANGUAGE');
insert into subject values(3,'JAVA ENTEPRISE EDITION');
insert into subject values(4,'VISUAL BASIC.NET');
insert into subject values(5,'ASP.NET');
select * from subject where s_name like "oracle%";
select * from subject where s_name like "j%";
select * from subject where s_name like "%.net";
select * from subject where s_name like "%er";
insert into Authors values(101, 'HERBERT SCHILD','12345','HERBERT@YAHOO.COM');
insert into Authors values(102, 'JAMES GOODWILL','12346','GOODWILL@HOTMAIL.COM');
insert into Authors values(103, 'DAVAID HUNTER','12347','HUNTER@HOTMAIL.COM');
insert into Authors values(104, 'STEPHEN WALTHER','12348','WALTHER@GMAIL.COM');
insert into Authors values(105, 'KEVIN LONEY','123490','LONEY@ORACLE.COM');
insert into Authors values(106, 'ED. ROMANS','123409','ROMANS@THESERVERSIDE.COM');
select * from Authors where a_id>103;
insert into publishers values(1,'WILLEY','98765','WDT@VSNL.NET');
insert into publishers values(2,'WROX','98766','INFO@WROX.COM');
insert into publishers values(3,'TATA MCGRAW-HILL','98764','FEEDBACK@TATAM.COM');
insert into publishers values(4,'TECHMEDIA','987653','BOOKS@TECHMEDIA.COM');
select * from publishers;
insert into title values(1001,'ASP.NET UNLEASHED',2,1,'12-4-02','p',540);
insert into title values(1002,'ORACLE10G COMP. REF.',1,2,'1-5-05','h',575);
insert into title values(1003,'MASTERING EJB',3,5,'3-2-05','p',475);
insert into title values(1004,'JAVA COMP. REF',4,3,'3-4-05','h',499);
select * from title;
create table titleauthors(titleid   int ,
    a_id int ,
    importance int,
    primary key(titleid, a_id),
    CONSTRAINT  titleauthors_titleid_FK FOREIGN KEY (titleid) REFERENCES title(titleid),
   CONSTRAINT  titleauthors_a_id_FK FOREIGN KEY (a_id) REFERENCES Authors(a_id) );
   insert into titleauthors values(1001,104,1);
   insert into titleauthors values(1002,105,1);
   insert into titleauthors values(1003,103,1);
   insert into titleauthors values(1004,102,2);
   select * from titleauthors;
   select * from Authors where a_name like "%er";
   select * from Publishers where pub_name like "%Hill";
   select * from Publishers where pub_name like "%Hill%";
   select * from title where price <500;
    select * from title where  pubdate<'3-4-05';
    select * from authors where a_id>'103';
    select * from title where titleid ='101' or price>400;
    select * from publishers where pub_name in('TECHMEDIA', 'WROX');
    select max(price) from title;
    select avg(importance) from titleauthors;
    select sum(price) from title;
    select sysdate();
    
    
    
    create table Employee (emp_id int,
    emp_name char(50));
    insert into Employee values(101,'mayuri');
    insert into Employee values(102,'mrunali');
    insert into Employee values(103,'meghana');
    insert into Employee values(104,'meetali');
    insert into Employee values(105,'prisha');
    alter table Employee add column dept_id varchar(25);
    alter table Employee modify column   emp_name varchar(12);
   SET SQL_SAFE_UPDATES = 0;
   update Employee set  emp_name = "Scott" where emp_id=105;
   truncate table employee;
   create table emp(SAL float(7,3));
   insert into emp values(1234.567);
   insert into emp values(1530.019);
   insert into emp values(1652.786);
   insert into emp values(1775.156);
   select * from emp;
   select round(1234.567);
   select round(1530.019);
   select round(1652.786);
   select round(1775.156);
   select truncate(1.22 , 0);
   select truncate(2.22,1);
   select truncate(4.44,4);
   select truncate(5,9);
   
   select ceil(10.9); 
   select ceil(20.2);
   select ceil(30);
   select ceil(40);
   select ceil(1001);
   
   select floor(60);
   select floor(22.6);
   
   select sign(-15);
   select sign(15);
   
   select mod(20,4);
   select mod(22,5);
   
   select sqrt(5);
   select sqrt(2);
   
   select power(2,2);
   select power(2,3);
   
   select concat('cdac','juhu');
   select concat('c',"dac");
   select concat('c','d','a','c');
   select concat("ju","hu");
   select lcase("CDAC");
   select upper("juhu");
   select reverse("juhu");
   select replace("juhu",'j','k');
   select replace("cdac",'c','e');
   select length("cdac juhu");
   select char_length("cdac juhu");
   select substr("cdac",'e');
   select substr("juhu",1);
   select strcmp("cdac","edac");
   select strcmp("cdac","cdac");
   select day('2020-12-1');
   select day('2020-12-25');
   select dayname('2020-12-1');
   select dayofmonth('2020-12-1');
   select dayofweek('2020-12-7');
   select dayofyear('2020-12-31');
   select week('2020-12-7');
   select weekday('2020-12-9');
   select weekofyear('2020-12-9');
   select curdate();
   select sysdate();
   select curtime();
   


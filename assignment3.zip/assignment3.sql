create database assignment3;
use assignment3;
create table Department (dept_id int primary key ,
dept_name varchar(50));
create table Employee(empid int,
	emp_name varchar(25),
	dept_id int,
    salary float,	 
    manager char(30),
    constraint dept_id_fk foreign key (dept_id) references department (dept_id)
);
insert into Department values(1,"Finance");
insert into Department values(2,"Training");
insert into Department values(3,"Marketing");
select * from Department;
insert into Employee values(1,"Arun",1,8000,4);
insert into Employee values(2,"kiran",1,7000,1);
insert into Employee values(3,"Scott",1,3000,1);
insert into Employee values(4,"Max",2,9000,null);
insert into Employee values(5,"Jack",2,8000,4);
insert into Employee values(6,"King",null,6000,1);
select * from Employee;
select * from Employee order by emp_name asc;
select * from Department order by dept_name desc;
select dept_id,sum(salary) from Employee group by dept_id;
select dept_id,sum(salary) from Employee group by dept_id having sum(salary)>17000;
select dept_id,sum(salary) from Employee group by dept_id having sum(salary)>18000;
select dept_id,sum(salary) from Employee group by dept_id having sum(salary)<20000;